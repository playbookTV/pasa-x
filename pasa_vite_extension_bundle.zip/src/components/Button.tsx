"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import clsx from "clsx"

type ButtonProps = {
  variant?: "primary" | "secondary" | "secondary-colored"
  size?: "large" | "medium" | "small"
  children: React.ReactNode
  className?: string
  goToSignin?: boolean
} & React.ButtonHTMLAttributes<HTMLButtonElement>

export const Button: React.FC<ButtonProps> = ({
  variant = "primary",
  size = "medium",
  children,
  className,
  goToSignin = false,
  onClick,
  ...props
}) => {
  const router = useRouter()

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (onClick) {
      onClick(e)
    }

    if (goToSignin && !e.defaultPrevented) {
      router.push("/login")
    }
  }

  return (
    <button
      className={clsx(
        "inline-flex items-center justify-center rounded-lg font-semibold font-inter overflow-hidden",
        {
          // Size classes
          "w-28 h-11 px-3 py-3 text-base": size === "large",
          "h-9 px-3 py-2 text-sm": size === "medium",
          "h-7 px-2 py-1 text-xs": size === "small",

          // Variant classes
          "bg-gradient-to-b from-[#4F46E5] to-[#3619C0] text-white rounded-lg shadow-[0px_1px_0px_0px_#757FF8_inset,0px_0px_0px_1px_#3516BF,0px_1px_3px_0px_rgba(143,39,9,0.20),0px_-2px_0px_0px_#3516BF_inset]":
            variant === "primary",
          "bg-white text-slate-800 shadow-[0px_1px_3px_0px_rgba(84,51,235,0.13),0px_0px_0px_1px_rgba(218,218,218,1.00),inset_0px_-2px_0px_0px_rgba(233,235,255,1.00)]":
            variant === "secondary",
          "bg-white text-indigo-600 shadow-[0px_1px_3px_0px_rgba(84,51,235,0.13),0px_0px_0px_1px_rgba(224,220,240,1.00),inset_0px_-2px_0px_0px_rgba(233,235,255,1.00)]":
            variant === "secondary-colored",
        },
        className,
      )}
      onClick={handleClick}
      {...props}
    >
      {children}
    </button>
  )
}

