import React from 'react';
import { ArrowLeft, Check } from 'lucide-react';
import { Button } from './Button';

interface OpenAnalyseResumeWidgetProps {
  onBack: () => void;
  onAutoFill: () => void;
  onGenerateCoverLetter: () => void;
  compatibility: number;
}

export const OpenAnalyseResumeWidget: React.FC<OpenAnalyseResumeWidgetProps> = ({
  onBack,
  onAutoFill,
  onGenerateCoverLetter,
  compatibility,
}) => {
  const keywords = [
    { name: 'Figma', matched: true },
    { name: 'Prototyping', matched: false },
    { name: 'UX Research', matched: true },
    { name: 'Web3', matched: false },
  ];

  return (
    <div className="w-80 h-96 p-2.5 justify-start items-start gap-2.5 inline-flex overflow-hidden">
      <div className="grow shrink basis-0 px-3 pt-4 pb-3 bg-white rounded-xl shadow-[0px_0px_2px_0px_rgba(0,0,0,0.15)] shadow-[0px_8px_40px_0px_rgba(0,0,0,0.04)] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.05)] flex-col justify-start items-start gap-4 inline-flex overflow-hidden">
        <div className="self-stretch justify-between items-center inline-flex">
          <button onClick={onBack} className="justify-center items-center gap-1 flex">
            <ArrowLeft className="w-4 h-6" />
            <div className="text-slate-900 text-sm font-semibold font-['Inter'] leading-tight">Back</div>
          </button>
          <div className="justify-end items-center gap-8 flex">
            <div className="justify-end items-center gap-5 flex">
              <div className="w-10 h-10 px-2 py-3 bg-slate-200 rounded-2xl flex-col justify-center items-center gap-2.5 inline-flex">
                <div className="text-slate-900 text-base font-semibold font-['Inter'] leading-7">CN</div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch h-96 p-4 bg-stone-100 rounded-lg flex-col justify-start items-center gap-6 flex overflow-hidden">
          <div className="self-stretch text-neutral-800 text-xl font-semibold font-['Inter']">Analyse Resume</div>
          <div className="self-stretch h-36 py-4 bg-gray-200 rounded-xl flex-col justify-start items-center gap-3.5 flex">
            <div className="w-24 h-24 relative">
              <div className="left-[21.97px] top-[31.54px] absolute text-zinc-900 text-3xl font-extrabold font-['Inter']">{compatibility}%</div>
              <div className="left-[21.61px] top-[63.37px] absolute text-zinc-900 text-xs font-medium font-['Inter']">Compatible</div>
              <div className="w-24 h-24 left-0 top-0 absolute">
                <div className="w-24 h-24 left-0 top-0 absolute rounded-full border-8 border-black/10" />
                <div className="w-24 h-24 left-0 top-0 absolute rounded-full border-8 border-indigo-600" style={{ clipPath: `inset(0 ${100 - compatibility}% 0 0)` }} />
              </div>
            </div>
          </div>
          <div className="self-stretch h-80 flex-col justify-start items-start gap-4 flex">
            <div className="self-stretch h-56 flex-col justify-start items-start gap-2.5 flex">
              <div className="self-stretch text-stone-950 text-base font-bold font-['Inter']">Keywords</div>
              <div className="self-stretch h-48 p-4 rounded-xl border border-black/10 flex-col justify-start items-start gap-4 flex">
                <div className="self-stretch text-zinc-900 text-sm font-normal font-['Inter'] leading-tight">
                  Your resume has {keywords.filter(k => k.matched).length} out of {keywords.length} keywords that appear in the job description. Try to get your score above 70% to increase your chances.
                </div>
                <div className="self-stretch justify-start items-start gap-2 inline-flex flex-wrap">
                  {keywords.map((keyword, index) => (
                    <div key={index} className={`p-2 bg-white rounded-2xl border border-neutral-200/90 justify-center items-center gap-1 flex overflow-hidden ${keyword.matched ? '' : 'opacity-30'}`}>
                      <div className="text-stone-950 text-sm font-medium font-['Inter']">{keyword.name}</div>
                      {keyword.matched && <Check className="w-3.5 h-3.5" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="self-stretch h-28 flex-col justify-start items-start gap-4 flex">
              <Button variant="primary" onClick={onAutoFill} className="w-full">
                Auto-fill Application
              </Button>
              <Button variant="secondary" onClick={onGenerateCoverLetter} className="w-full">
                Generate Cover Letter
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

